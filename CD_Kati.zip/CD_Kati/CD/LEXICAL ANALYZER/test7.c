// test case to check control and looping statements

#include<stdio.h>
int main () {

   /* local variable definition */
   int a = 1;

   /* do loop execution */
   do {
      printf("value of a: %d\n", a);
      a = a + 1;
   }
   while ( a < 5 )
 
   return 0;
}
