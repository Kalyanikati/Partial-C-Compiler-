#include<stdio.h>
int main ()
{
 int a=4;
while(a!=0)
{
printf("%d",a);
a--;
}
return 0;
}